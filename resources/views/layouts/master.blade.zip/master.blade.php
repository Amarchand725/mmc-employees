<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="public/assets/css/style.css">
    <link rel="icon" href="public/assets/images/logo.png " type="image/png" sizes="16x16">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.2/css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <title>Mad Minds Creative</title>
</head>

<body>
   {{--  <!-- Header -->
    @include('layouts.website.header')
    <!-- Header End --> --}}

    @yield('content')

    {{--     <!-- Footer -->
    @include('layouts.website.footer')
    <!-- Footer End --> --}}


    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/simplePagination.js/1.6/jquery.simplePagination.js"></script>
    <script>
        $(document).on('click', ".custom-fields-three", function() {
        var html = '<div class="dynamic-repeater-three">'+
                    '<div class="row children-detail">'+
                        '<div class="form-group col-md-3">'+
                            '<input type="text" name="child_names[]" class="form-control" placeholder="Name"> '+
                        '</div>'+
                        '<div class="form-group col-md-2">'+
                            '<select name="child_genders[]" id="" class="form-control">'+
                                '<option value="male" selected>Male</option>'+
                                '<option value="female">Female</option>'+
                            '</select>'+
                        '</div>'+
                        '<div class="form-group col-md-2">'+
                            '<input type="date" name="child_dobs[]" class="form-control" placeholder="Date of Birth"> '+
                        '</div>'+
                        '<div class="form-group col-md-3">'+
                            '<input type="text" name="child_cnic_nos[]" class="form-control" placeholder="Cnic No"> '+
                        '</div>'+
                        '<div class="col-2 ">'+
                            '<button type="button" class="btn btn-danger remove-btn-two">Delete</button>'+
                        '</div>'+
                    '</div>'+
                '</div>';
            $('#dynamic-repeater-three').append(html);
        });

        $(document).on('click', '.remove-btn-two',function(){
            $(this).parents('.dynamic-repeater-three').remove();
        });
    </script>
    <script>
        $(document).on('click', ".custom-fields", function() {
        var html = '<div class="dynamic-repeater">'+
                        '<div class="row children-detail">'+
                            '<div class="form-group col-md-2">'+
                                '<input type="text" class="form-control" placeholder="Course/Training Title">'+
                            '</div>'+
                            '<div class="form-group col-md-2">'+
                                '<input type="tel" class="form-control" placeholder="Year">'+
                            '</div>'+
                            '<div class="form-group col-md-2">'+
                                '<input type="text" class="form-control" placeholder="Name of Institutions">'+
                            '</div>'+
                            '<div class="form-group col-md-2">'+
                                '<input type="text" class="form-control" placeholder="Course Period?">'+
                            '</div>'+
                            '<div class="form-group col-md-2">'+
                                '<input type="text" class="form-control" placeholder="Division / Grade">'+
                            '</div>'+
                            '<div class="col-2 ">'+
                            '<button type="button" class="btn btn-danger remove-btn">Delete</button>'+
                            '</div>'+

                        '</div>'+
                    '</div>';
            $('#dynamic-repeater').append(html);
        });

        $(document).on('click', '.remove-btn',function(){
            $(this).parents('.dynamic-repeater').remove();
        });
    </script>
    <script>
        $(document).on('click', ".custom-fields-two", function() {
        var html = '<div class="dynamic-repeater-two">'+
                    '<div class="row children-detail">'+
                        '<div class="form-group col-md-3">'+
                            '<input type="text" class="form-control" placeholder="Particulars"> '+
                        '</div>'+
                        '<div class="form-group col-md-2">'+
                            '<input type="tel" class="form-control" placeholder="Year"> '+
                        '</div>'+
                        '<div class="form-group col-md-2">'+
                            '<input type="text" class="form-control" placeholder="Name of Institutions"> '+
                        '</div>'+
                        '<div class="form-group col-md-3">'+
                            '<input type="text" class="form-control" placeholder="Division / Grade"> '+
                        '</div>'+
                       '<div class="col-2 ">'+
                            '<button type="button" class="btn btn-danger remove-btn-two">Delete</button>'+
                        '</div>'+
                    '</div>'+
                '</div>';
            $('#dynamic-repeater-two').append(html);
        });

        $(document).on('click', '.remove-btn-two',function(){
            $(this).parents('.dynamic-repeater-two').remove();
        });
    </script>
    <!-- Script for pagination -->

    <!-- Script for pagination -->
</body>
</html>
